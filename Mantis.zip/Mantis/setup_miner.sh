#!/bin/bash
# MANTIS Advanced Miner Setup Script

set -e

echo "🚀 Setting up MANTIS Advanced Miner..."

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo "⬆️ Upgrading pip..."
pip install --upgrade pip

# Install requirements
echo "📥 Installing requirements..."
pip install -r miner_requirements.txt

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p logs
mkdir -p models
mkdir -p storage

# Create .env template if it doesn't exist
if [ ! -f ".env" ]; then
    echo "📝 Creating .env template..."
    cat > .env << EOF
# Cloudflare R2 Configuration
R2_ACCOUNT_ID=e82a89e4f742154ce30275878a7bf172
R2_WRITE_ACCESS_KEY_ID=20c42cb0cbebb720cc09c15beed6e1ef
R2_WRITE_SECRET_ACCESS_KEY=2e694dfd99ede684c29319cca8603a2184372bba6123571e26a634aae1655827

# Optional: Custom settings
# MINING_INTERVAL=60
# LOCK_TIME_SECONDS=30
EOF
    echo "⚠️  Please edit .env file with your R2 credentials"
fi

# Set executable permissions
chmod +x advanced_miner.py

echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "1. Edit .env file with your R2 credentials"
echo "2. Update miner_config.py with your wallet info"
echo "3. Run: python advanced_miner.py --wallet.name YOUR_WALLET --wallet.hotkey YOUR_HOTKEY"
echo ""
echo "For commit-only mode: python advanced_miner.py --wallet.name YOUR_WALLET --wallet.hotkey YOUR_HOTKEY --commit-only"